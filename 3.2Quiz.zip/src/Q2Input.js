import React from 'react'

function Q2Input() {
  return (
    <div>
      <input></input>
    </div>
  )
}

export default Q2Input
