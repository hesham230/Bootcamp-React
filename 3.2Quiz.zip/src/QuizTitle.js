import React from 'react'

const QuizTitle = () => {
  return (
    <div>
      <h3>How Do You Like Front End?</h3>
    </div>
  )
}

export default QuizTitle
