import React from 'react'

const Q2Title = () => {
  return (
    <div>
      <h5>What is your favourite front end feature/topic?</h5>
    </div>
  )
}

export default Q2Title
