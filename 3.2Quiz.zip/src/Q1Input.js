import React from 'react'

const Q1Input = () => {
  return (
    <div>
 <form action="/action_page.php"
  oninput="x.value=parseInt(a.value)+parseInt(b.value)"></form>
  0
  <input type="range" id="a" name="a" value="50"></input>
  100
    </div>
  )
}

export default Q1Input
