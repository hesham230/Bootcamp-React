import React from 'react';
import ReactDom from 'react-dom';
import QuizTitle from './QuizTitle';
import Q1 from './Q1';
import Q2 from './Q2';
import './style.css';

const App = () => {
  return(
    <div className="container">
      <QuizTitle />
      <Q1 />
      <Q2 />
    </div>
  );
}

ReactDom.render(<App />, document.querySelector('#root'));