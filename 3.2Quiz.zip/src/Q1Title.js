import React from 'react'

const Q1Title = () => {
  return (
    <div>
      <h5>How Much You Love Front End?</h5>
    </div>
  )
}

export default Q1Title
