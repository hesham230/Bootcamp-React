import React from 'react';
import axios from 'axios';
import './style.css';

const URL = "https://api.chucknorris.io/jokes/";

class Category extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      joke: "",
      categories: [],
      category: "",
    };

    this.setup = this.setup.bind(this);
    this.getJoke = this.getJoke.bind(this);
    this.setCategory = this.setCategory.bind(this);
  }

  componentDidMount() {
    this.setup();
  }

  render() {
    
    return (
      <div>
        <div>
           <div>
            {this.state.joke}
           </div>
        </div>

        <div>
          <input
            data={this.state.categories}
            placeholder="Choose Category"
            onSelect={val => {
              this.setCategory(val);
            }}
          />
          <button
              onClick={() => {
              this.getJoke();
            }}
          >
            Get a joke by category
          </button>
        </div>
        <div />
      </div>
    );
  }

  setup() {
    fetch(URL + "categories")
      .then(resp => resp.json())
      .then(resp => {
        const categories = resp.map(val => {
          return { label: val, value: val };
        });
        this.setState({ categories: categories });
        this.setState({ category: "random" });
      })
      .then(x => {
        return fetch(URL + "random");
      })
      .then(resp => resp.json())
      .then(resp => {
        this.setState({ joke: resp.value, loading: false });
      })
      .catch(err =>
        console.log(err)
      );
  }

  getJoke() {
    let url = URL + "random";
    if (this.state.category !== "random") {
      url += "?category=" + this.state.category;
    }

    
    fetch(url)
      .then(resp => resp.json())
      .then(resp => {
        this.setState({ joke: resp.value });
      })
      .catch(err =>
        console.log(err)
      );
  }

  setCategory(category) {
    this.setState({ category: category });
  }
}

  
export default Category;