import React, { Component } from 'react';
import './style.css';

const Buttons = (props) => {
  return(
    <div className="wrapper">
      <button className={props.classes ?props.classes.join(' '):null}>{props.text}</button>
    </div>
  )
}

export default Buttons;
