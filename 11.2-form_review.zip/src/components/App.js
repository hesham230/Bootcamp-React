import React from 'react';
import  UserForm from './UserForm';

class App extends React.Component {
  render(){
    return (
      <div>
        <UserForm />
      </div>
    );
  }
}

export default App;
