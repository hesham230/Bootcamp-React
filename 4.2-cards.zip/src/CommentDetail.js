import React from 'react';
import './style.css';

const CommentDetail = props => {
  return (
    <div className="comment">
      <a href="/" className="avatar">
        <img alt="avatar" src={props.avatar} />
      </a>
      <div className="content">
        <p className="title">
          {props.title}
        </p>
        <div className="decription">{props.decription}</div>
      </div>
      <div>
        <a href="#">SHARE</a>
        <br/>
        <a href="#">EXPLORE</a>
      </div>
    </div>
  );
};

export default CommentDetail;
