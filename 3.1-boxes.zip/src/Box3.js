import React from 'react'
import Box4 from './Box4'


const Box3 = () =>{
  return (
    <div className="box4 flex-center">
    <Box4 />
    <div className="box4 flex-center">
    <Box4 />
    </div>
    </div>
  );
}

export default Box3;
