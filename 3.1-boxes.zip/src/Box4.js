import React from 'react'

const Box4 = () =>{
  return (
    <div className="box4 flex-center">
      
    </div>
  );
}

export default Box4;