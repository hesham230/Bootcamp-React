import React from 'react';
import logo from './logo.svg';
import './App.css';
import Box1 from './Box1'
function App() {
  return (
    <div className="App">
      <div className="box1 flex-center"> 
      <Box1 />
    </div>
    </div>
  );
}

export default App;
