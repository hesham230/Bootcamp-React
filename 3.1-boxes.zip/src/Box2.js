import React from 'react'
import Box3 from './Box3'

const Box2 = () =>{
  return (
    <div className="box3 flex-center">
    <Box3 />
    </div>
  );
}

export default Box2;
