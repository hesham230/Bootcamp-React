import React, { Component } from 'react';
import './style.css';

class Spinner extends Component {
  render() {
    return (
      <div>
        <div class="loader"></div>
        {/* <div class="spinner"></div> */}
      </div>
    )
  }
}

export default Spinner
